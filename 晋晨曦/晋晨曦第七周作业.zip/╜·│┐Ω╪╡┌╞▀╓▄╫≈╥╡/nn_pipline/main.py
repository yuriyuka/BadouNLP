# -*- coding: utf-8 -*-

import torch
import os
import random
import os
import numpy as np
import logging
from config import Config
from model import TorchModel, choose_optimizer
from evaluate import Evaluator
from loader import load_data
from cutHomeworkDatas import cut
#[DEBUG, INFO, WARNING, ERROR, CRITICAL]
logging.basicConfig(level=logging.INFO, format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

"""
模型训练主程序
"""


seed = Config["seed"] 
random.seed(seed)
np.random.seed(seed)
torch.manual_seed(seed)
torch.cuda.manual_seed_all(seed)

def main(config):
    #创建保存模型的目录
    if not os.path.isdir(config["model_path"]):
        os.mkdir(config["model_path"])
    #切分数据
    cut()
    #加载训练数据
    train_data = load_data(config["train_data_path"], config)
    #加载模型
    model = TorchModel(config)
    # 标识是否使用gpu
    cuda_flag = torch.cuda.is_available()
    if  cuda_flag:
        # logger.info("gpu可以使用，迁移模型至gpu")
        model = model.cuda()
    #加载优化器
    optimizer = choose_optimizer(config, model)
    #加载效果测试类
    evaluator = Evaluator(config, model, logger)
    #训练
    for epoch in range(config["epoch"]):
        epoch += 1
        model.train()
        logger.info("epoch %d begin" % epoch)
        train_loss = []
        for index, batch_data in enumerate(train_data):
            if  cuda_flag:
                batch_data = [d.cuda() for d in batch_data]

            optimizer.zero_grad()
            input_ids, labels = batch_data   #输入变化时这里需要修改，比如多输入，多输出的情况
            loss = model(input_ids, labels)
            loss.backward()
            optimizer.step()

            train_loss.append(loss.item())
            # if index % int(len(train_data) / 2) == 0:
            #     logger.info("batch loss %f" % loss)
        # logger.info("epoch average loss: %f" % np.mean(train_loss))
        acc,cost_time = evaluator.eval(epoch)
        
    # model_path = os.path.join(config["model_path"], "epoch_%d.pth" % epoch)
    # torch.save(model.state_dict(), model_path)  #保存模型权重
    return acc,cost_time
if __name__ == "__main__":
    # main(Config)

    # for model in ["cnn"]:
    #     Config["model_type"] = model
    #     print("最后一轮准确率：", main(Config), "当前配置：", Config["model_type"])

    #对比所有模型
    #中间日志可以关掉，避免输出过多信息
    # 超参数的网格搜索
    import pandas as pd
    import winsound
    from tkinter import Tk, Label

    def sound_alarm():
        """播放提示音"""
        winsound.MessageBeep(winsound.MB_ICONASTERISK)
    def show_popup():
        """显示弹窗"""
        root = Tk()
        root.wm_attributes('-topmost', 1)  # 置顶显示
        root.title("训练完成提醒")
        root.geometry("300x150")  # 设置弹窗大小
        label = Label(root, text="模型训练已完成！", font=("微软雅黑", 16))
        label.pack(pady=50)
        sound_alarm()  # 播放声音
        root.mainloop()


    datas_to_excel=pd.DataFrame()
    tag=0
    import time
    start_time = time.perf_counter()

    for model in ["bert_mid_layer","gated_cnn", 'bert', 'lstm']:
        Config["model_type"] = model
        for lr in [1e-3,1e-4]:
            Config["learning_rate"] = lr
            for hidden_size in [128]:
                Config["hidden_size"] = hidden_size
                for batch_size in [64, 128]:
                    Config["batch_size"] = batch_size
                    for pooling_style in ["avg", 'max']:
                        Config["pooling_style"] = pooling_style
                        rate,cost_time=main(Config)
                        print("最后一轮准确率：", rate, "当前配置：", Config)
                        tag+=1
                        datas_to_excel[tag]=[f"{cost_time}",
                                             f"{model}",
                                             f"{lr}",
                                             f"hidden_size={hidden_size}",
                                             f"batch_size={batch_size}",
                                             f"{pooling_style}",
                                             f"{round(rate,2)}"]
                        print(f"耗时={cost_time},{model},lr={lr},hidden_size={hidden_size},batch_size={batch_size},pooling_style={pooling_style},{round(rate,2)}")
    end_time = time.perf_counter()
    print(f"模型训练和测试共计用时{end_time - start_time} seconds ={(end_time - start_time) // 60} min{int((end_time - start_time) %60)}second")
    print(datas_to_excel)
    datas_to_excel.to_excel(f"训练信息{time.perf_counter()}.xlsx")
    show_popup()







