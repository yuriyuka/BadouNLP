import os
import json
import pandas as pd
from sklearn.model_selection import train_test_split
def cut():
    df=pd.read_csv("../文本分类练习.csv")
    train_set,test_set=train_test_split(df,
                                        test_size=0.2,
                                        shuffle=True,
                                        stratify=df['label'])
    output_dir=r"..\homeworkPracticeData"
    train_dir=os.path.join(output_dir,"train_set.jsonl")
    test_dir=os.path.join(output_dir,"test_set.jsonl")
    datas_dir=os.path.join(output_dir,"datas_set.jsonl")

    def writepath(path,data):
        with open(path,"w",encoding='utf-8') as f:
            data = data.to_dict('records')
            for d in data:
                f.write(json.dumps(d,ensure_ascii=False)+'\n')

    writepath(train_dir,train_set)
    writepath(test_dir,test_set)
    writepath(datas_dir,df)
if __name__=="__main__":
    cut()