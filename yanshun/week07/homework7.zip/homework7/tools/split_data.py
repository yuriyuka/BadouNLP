import pandas as pd
from sklearn.model_selection import train_test_split
import json

# 读取 CSV 文件
data = pd.read_csv('../dataset/data.csv')

# 假设标签列名为 'label'，特征列是除了标签列之外的其他列
X = data['review']
y = data['label']

# 按照 4:1 的比例划分训练集和验证集，同时保证两类数据平均划分
X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 合并特征和标签，形成完整的训练集和验证集
train_data = pd.concat([y_train, X_train], axis=1)
val_data = pd.concat([y_val, X_val], axis=1)

# 将训练集转换为标准 JSON 数组格式并保存
train_json = train_data.to_json(orient='records', force_ascii=False, lines=True)
with open('../dataset/train_data.json', 'w', encoding='utf-8') as f:
    f.write(train_json)

# 将验证集转换为标准 JSON 数组格式并保存
val_json = val_data.to_json(orient='records', force_ascii=False, lines=True)
with open('../dataset/val_data.json', 'w', encoding='utf-8') as f:
    f.write(val_json)

print("训练集和验证集划分完成，已保存为 train_data.json 和 val_data.json")