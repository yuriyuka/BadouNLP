import json
import numpy as np
from config import Config

# 定义函数用于分析数据集
def analyze_dataset(data_path, label_to_index):
    positive_count = 0
    negative_count = 0
    text_lengths = []

    with open(data_path, encoding="utf8") as f:
        for line in f:
            line = json.loads(line)
            label = line["label"]
            review = line["review"]

            # 假设0为负样本，1为正样本，这里可以根据实际情况修改
            if label == 0:
                negative_count += 1
            else:
                positive_count += 1

            text_lengths.append(len(review))

    # 计算文本平均长度
    average_length = np.mean(text_lengths)

    # 计算文本最大长度
    max_length = np.max(text_lengths)

    # 计算第95%个最大文本长度
    sorted_lengths = sorted(text_lengths, reverse=False)
    index_95_percent = int(len(sorted_lengths) * 0.95)
    length_95_percent = sorted_lengths[index_95_percent]

    print(f"正样本数: {positive_count}")
    print(f"负样本数: {negative_count}")
    print(f"文本平均长度: {average_length:.2f}")
    print(f"文本最大长度: {max_length:.2f}")
    print(f"第95%个最大文本长度: {length_95_percent:.2f}")

    return positive_count, negative_count, average_length, max_length, length_95_percent

# 加载配置
config = Config

# 从loader.py中获取标签到索引的映射
label_to_index = {
    0: '差评', 1: '好评'
}
label_to_index = dict((y, x) for x, y in label_to_index.items())

# 分析训练集
print("训练集数据分析：")
train_positive, train_negative, train_avg_length, train_max_length, train_95_length = analyze_dataset(config["train_data_path"], label_to_index)

# 分析验证集
print("\n验证集数据分析：")
val_positive, val_negative, val_avg_length, val_max_length, val_95_length = analyze_dataset(config["valid_data_path"], label_to_index)

"""
训练集数据分析：
正样本数: 3200
负样本数: 6389
文本平均长度: 24.87
文本最大长度: 437.00
第95%个最大文本长度: 69.00

验证集数据分析：
正样本数: 800
负样本数: 1598
文本平均长度: 25.76
文本最大长度: 463.00
第95%个最大文本长度: 71.00
"""